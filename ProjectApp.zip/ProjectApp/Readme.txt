API paths for testing:
/api/menu/
/api/bookings/
/api/registration/
/api/token/
/api/token/refresh/

